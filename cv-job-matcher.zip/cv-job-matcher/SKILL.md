---
name: cv-job-matcher
description: >
  Guides the user through a structured CV-to-job-spec matching workflow: first prompts them to upload their CV (PDF or Word), then asks them to paste the job description, and finally delivers a detailed match analysis with a SWOT breakdown (Strengths, Weaknesses, Opportunities, Threats). Use this skill whenever the user mentions matching a CV or resume to a job, wants to know how well they fit a role, asks for a job fit analysis, mentions "SWOT" in a recruitment context, says "check my CV against a job spec/description", or asks whether they should apply for a role. Trigger even for casual phrasings like "does my CV match?", "am I a good fit for this job?", or "analyse my CV for this role".
---

# CV ↔ Job Spec Match Analyser

A structured, two-step intake workflow followed by a rich match analysis and SWOT.

---

## Step 1 — Gate: CV file present?

**CHECK**: Is there an uploaded file (PDF or DOCX) anywhere in the conversation?

- **NO** → Say: "To get started, please **upload your CV** (PDF or Word .docx), then press **Enter** to continue." Then **STOP. Do not read any further in these instructions. Do not proceed to Step 2 or beyond.**
- **YES** → Continue to Step 2.

---

## Step 2 — Gate: Job description present?

**CHECK**: Has the user provided a job description in their messages? This means a substantial block of text describing a role — not just "match my CV" or a file upload. A URL alone does not count.

- **NO** → Say: "CV received — thanks! Now please **paste the job description** below and press **Enter** to run the analysis." Then **STOP. Do not proceed to Step 3 or beyond.**
- **YES** → Continue to Step 3.

> **CRITICAL**: These two gates are sequential and mandatory. Even if a CV file is present in the conversation, you MUST stop and ask for the job description before doing any analysis. Never skip or merge these steps.

---

## Step 3 — Read the CV

Use the appropriate method based on file type:

- **PDF**: use the `pdf` skill approach — extract text via bash/python (`pdfminer.six` or `pypdf`).
- **DOCX**: use the `docx` skill approach — extract text via `python-docx`.

Extract all readable text. If extraction fails, tell the user and ask them to paste the CV text manually.

---

## Step 4 — Run the Match Analysis

Produce the output in **five sections**:

### 4a. Match Score

Give an overall fit percentage (0–100%) with a one-sentence rationale. Be calibrated — avoid inflating scores.

Example:
> **Match Score: 73%** — Strong technical alignment, but the role requires 5+ years of people management that isn't evidenced in the CV.

---

### 4b. Detailed Match Breakdown

Cover each of these dimensions in a short paragraph or bullet list:

| Dimension | What to assess |
|---|---|
| **Must-have skills** | Which required skills are present / missing? |
| **Nice-to-have skills** | Which preferred skills are present / missing? |
| **Experience level** | Years and seniority match? |
| **Domain / industry** | Relevant sector experience? |
| **Education / certifications** | Required qualifications met? |
| **Keywords & ATS** | Key terms from the job spec present in the CV? |

For each dimension, use a clear ✅ / ⚠️ / ❌ indicator:
- ✅ Strong match
- ⚠️ Partial match or unclear
- ❌ Gap identified

---

### 4c. SWOT — Graphical 2×2 SVG

Render the SWOT as an SVG diagram **directly in your response — no code fences, no backticks, no markdown wrapping**. Output the raw `<svg>` element so it renders inline.

---

#### Percentage logic — read carefully before assigning any numbers

**S + W = 100%.** These are the only two numbers that split the full internal picture. Decide the split first (e.g. S=65%, W=35%), then assign individual item weights *within each quadrant* that sum exactly to that quadrant's total:
- S items: s1 + s2 + s3 + … = S%
- W items: w1 + w2 + w3 + … = W%
- S% + W% = 100% ✓

**O + T = 100%.** Same principle for the external picture:
- O items: o1 + o2 + … = O%
- T items: t1 + t2 + … = T%
- O% + T% = 100% ✓

**The progress bar for each item represents that item's share of its own quadrant total, not of 100%.** Bar width = 220 × (item_pct / quadrant_total). Example: if S=65% and a strength item is 30%, its bar width = 220 × (30/65) = 101px. This way bars fill proportionally within their quadrant and the longest bar always nearly fills the track.

Include as many items per quadrant as the analysis requires — no cap.

---

#### Layout

**Quadrant positions:** S=top-left (x=20,y=20), W=top-right (x=360,y=20), O=bottom-left (x=20,y=BOTTOM_Y), T=bottom-right (x=360,y=BOTTOM_Y). Each rect: width=300, rx=12, stroke-width=0.5.

**Quadrant height:** QUAD_HEIGHT = 50 + (number_of_items × 33). Both quadrants in the same row use the height of the taller one. BOTTOM_Y = 20 + top_row_height + 20. TOTAL_HEIGHT = BOTTOM_Y + bottom_row_height + 20.

**Divider lines** (no labels, just the cross):
```
<line x1="340" y1="20" x2="340" y2="[TOTAL_HEIGHT-20]" stroke="var(--color-border-tertiary)" stroke-width="0.5" stroke-dasharray="4 3"/>
<line x1="20" y1="[BOTTOM_Y-10]" x2="660" y2="[BOTTOM_Y-10]" stroke="var(--color-border-tertiary)" stroke-width="0.5" stroke-dasharray="4 3"/>
```

**Color classes:** S=`c-teal`, W=`c-amber`, O=`c-blue`, T=`c-coral`. Apply to the `<g>` wrapping each quadrant's rect and header text.

**Accent fill colors:** S=#1D9E75, W=#BA7517, O=#185FA5, T=#993C1D

---

#### Per-quadrant SVG pattern

QUAD_X = left edge (20 or 360). QUAD_Y = top edge. ROW_Y for item i = QUAD_Y + 58 + (i × 33).

```
<g class="[COLOR_CLASS]">
  <rect x="QUAD_X" y="QUAD_Y" width="300" height="QUAD_HEIGHT" rx="12" stroke-width="0.5"/>
  <text class="th" x="QUAD_X+16" y="QUAD_Y+28" dominant-baseline="central">[EMOJI] [Label] — [QUADRANT_TOTAL]%</text>
</g>

<!-- For each item i: -->
<text class="ts" x="QUAD_X+16" y="ROW_Y" fill="var(--color-text-secondary)">[Item label]</text>
<rect x="QUAD_X+16" y="ROW_Y+10" width="220" height="5" rx="2" fill="var(--color-border-tertiary)"/>
<rect x="QUAD_X+16" y="ROW_Y+10" width="[220*(item_pct/quadrant_total)]" height="5" rx="2" fill="[ACCENT]"/>
<text class="ts" x="QUAD_X+242" y="ROW_Y+13" dominant-baseline="central" text-anchor="start" fill="[ACCENT]">[item_pct]%</text>
```

Always include the `<defs>` arrow marker block at the top of the SVG.

---

**Quadrant definitions:**
- **Strengths** — things the CV directly evidences that map to the role's needs
- **Weaknesses** — gaps, missing keywords, underrepresented experience, or red flags a hiring manager would notice
- **Opportunities** — transferable skills, adjacent experience, or angles to highlight in a cover letter or interview
- **Threats** — external/competitive risks: missing required qualifications, likely strong competition, role being a stretch

---

### 4d. Actionable Recommendations (optional but strongly encouraged)

After the SWOT, add 3–5 concrete bullet points the candidate can act on:
- CV tweaks (add missing keywords, reframe experience)
- Cover letter angles to emphasise
- Skills or certifications worth acquiring
- Whether to apply, and with what confidence level

---

## Tone & Format Guidelines

- Be honest but constructive — candidates benefit from candour, not flattery.
- Use clear headings and short paragraphs for scannability.
- If the job spec is vague or the CV is sparse, note the limitation and flag where assumptions were made.
- Keep the full output under ~600 words unless the role or CV is unusually complex.

---

## Edge Cases

| Situation | How to handle |
|---|---|
| User pastes CV as text (no upload) | Accept it and proceed |
| User provides a URL to a job posting | Extract visible text; if inaccessible, ask them to paste it |
| CV is image-only PDF (scanned) | Warn that OCR is limited; ask for text paste |
| Multiple CVs uploaded | Ask which one to use |
| Job spec is very short / vague | Note limitations; do best-effort analysis and flag assumptions |

---
name: resume-ats-checker
description: >
  Run a full ATS (Applicant Tracking System) validation on a user's resume. This skill guides the user through uploading their CV/resume, performs a comprehensive ATS compatibility audit, publishes a structured report with scores and issues, suggests specific improvements, and optionally applies those changes automatically to produce an updated resume file. Trigger this skill whenever the user mentions ATS, resume scanning, applicant tracking, CV optimization, resume parsing, keyword matching, resume scoring, or asks if their resume will pass automated screening. Also trigger for phrases like "check my resume", "will my CV get past ATS", "optimize my resume for ATS", "ATS-friendly resume", or "resume audit". Always use this skill — even for casual phrasing — when the user wants any form of automated resume analysis or improvement.
---

# Resume ATS Checker Skill

A structured workflow for auditing a resume against ATS criteria, reporting findings, and optionally applying fixes.

---

## Step 1 — Request the Resume Upload

Greet the user and ask them to upload their resume. Be warm and clear. Use this exact phrasing:

> "Please upload your resume (PDF or Word .docx preferred).
>
> **Please press ENTER to continue** once your file is uploaded."

Wait. Do not proceed until the user has confirmed and a file path is visible under `/mnt/user-data/uploads/`.

---

## Step 2 — Read the Uploaded File

Once the user continues, read the skill for file handling:

- Check `/mnt/user-data/uploads/` for the uploaded file
- If PDF → read with `pdftotext` or `pypdf2` via bash
- If DOCX → use `python-docx` to extract text via bash
- Store the full extracted text for analysis

```bash
# PDF extraction example
pdftotext /mnt/user-data/uploads/resume.pdf - 2>/dev/null || \
  python3 -c "
import sys
try:
    import pypdf
    reader = pypdf.PdfReader('/mnt/user-data/uploads/resume.pdf')
    text = '\n'.join(p.extract_text() or '' for p in reader.pages)
    print(text)
except Exception as e:
    print(f'Error: {e}', file=sys.stderr)
"
```

```bash
# DOCX extraction example
python3 -c "
import docx, sys
doc = docx.Document('/mnt/user-data/uploads/resume.docx')
text = '\n'.join(p.text for p in doc.paragraphs)
print(text)
"
```

---

## Step 3 — Run ATS Analysis

Analyse the extracted text against all ATS criteria below. Do this thoroughly in your internal reasoning before writing the report.

### ATS Criteria Checklist

#### 1. File & Format (10 pts)
- [ ] Submitted as PDF or DOCX (not image-based PDF, JPG, etc.)
- [ ] File is machine-readable (text is selectable, not scanned)
- [ ] Single-column layout (multi-column confuses parsers)
- [ ] No tables, text boxes, or headers/footers hiding content

#### 2. Contact Information (10 pts)
- [ ] Full name present
- [ ] Phone number present
- [ ] Email address present
- [ ] LinkedIn or professional URL present (bonus)
- [ ] Location (city/country) present

#### 3. Section Headers (15 pts)
- [ ] Standard headers used: Experience, Education, Skills, Summary/Objective
- [ ] Headers are plain text (not images or icons)
- [ ] No creative/unusual section names (e.g., "My Journey" instead of "Experience")

#### 4. Work Experience (20 pts)
- [ ] Each role has: Job Title, Company Name, Dates (month + year)
- [ ] Dates formatted consistently (e.g., Jan 2022 – Mar 2024)
- [ ] Bullet points start with strong action verbs
- [ ] Quantified achievements present (%, $, numbers)
- [ ] No unexplained employment gaps > 6 months

#### 5. Keyword & Skills Density (20 pts)
- [ ] Hard skills explicitly listed (technologies, tools, certifications)
- [ ] Skills section present and clearly labelled
- [ ] Keywords appear in context, not just dumped in a list
- [ ] Industry-relevant terminology used

#### 6. Education (10 pts)
- [ ] Degree title, institution name, graduation year present
- [ ] Certifications listed with issuing body and date

#### 7. Formatting & Readability (10 pts)
- [ ] Font is standard (Arial, Calibri, Times New Roman, etc.)
- [ ] Font size 10–12pt for body, 14–16pt for name
- [ ] No special characters, emojis, or graphics in text
- [ ] Consistent date formatting throughout
- [ ] Length appropriate (1 page for < 5 yrs exp; 2 pages max)

#### 8. ATS Red Flags (5 pts — deduct for each found)
- [ ] No images, logos, or photos embedded
- [ ] No headers/footers with critical info (ATS often skips these)
- [ ] No text in text boxes (ATS cannot read these)
- [ ] No hyperlinks as the sole representation of info

---

## Step 4 — Publish the ATS Report

Present a structured report using the following format. Use a `show_widget` visualizer if available, otherwise well-formatted markdown.

### Report Structure

```
ATS COMPATIBILITY REPORT
========================
Overall Score: XX / 100    [PASS ≥ 70 | REVIEW 50–69 | FAIL < 50]

SECTION SCORES
--------------
File & Format          X / 10
Contact Information    X / 10
Section Headers        X / 15
Work Experience        X / 20
Keywords & Skills      X / 20
Education              X / 10
Formatting             X / 10
Red Flags Deduction    -X

ISSUES FOUND
------------
🔴 CRITICAL (will cause rejection):
  - [list each]

🟡 WARNINGS (may reduce score):
  - [list each]

🟢 PASSED:
  - [list each]

TOP 5 RECOMMENDED IMPROVEMENTS
-------------------------------
1. [Specific, actionable change]
2. ...
```

---

## Step 5 — Suggest Specific Changes

After the report, list concrete, copy-paste-ready suggestions. Examples:

- "Change your Summary header from 'About Me' to 'Professional Summary'"
- "Add metrics to this bullet: 'Managed team' → 'Managed team of 8 engineers, reducing delivery time by 30%'"
- "Move your Skills section above Education for faster ATS parsing"
- "Replace the table in your Skills section with a plain comma-separated list"

---

## Step 6 — Offer Automatic Application of Changes

After presenting the suggestions, ask:

> "Would you like me to **automatically apply these changes** and produce an updated, ATS-optimised version of your resume?
>
> I can generate a clean `.docx` file with all fixes applied. Just say **yes** to proceed."

### If user says yes:

1. Read `/mnt/skills/public/docx/SKILL.md` for Word document generation
2. Reconstruct the resume content with all fixes applied:
   - Standardise section headers
   - Rewrite flagged bullets with action verbs + metrics where possible
   - Remove problematic formatting
   - Ensure clean single-column structure
3. Save the updated resume to `/mnt/user-data/outputs/resume_ATS_optimised.docx`
4. Call `present_files` with the output path
5. Add a brief summary of every change made

### If user says no:

Acknowledge gracefully and offer to answer any follow-up questions about specific suggestions.

---

## Notes & Tips for Claude

- Be encouraging — job searching is stressful. Frame issues as "opportunities to improve" rather than failures.
- If the resume is already well-optimised (score ≥ 85), say so clearly and celebrate it.
- If you cannot extract text (scanned image PDF), tell the user and ask them to provide a text-based version.
- Never fabricate content. When suggesting rewrites, preserve the user's original experience and facts — only improve phrasing and structure.
- Always calculate scores numerically and show your working.
